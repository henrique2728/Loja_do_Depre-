﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public static int saldo;
    void Start()
    {
        saldo = 10000;
    }
    private void Update()
    {
        saldo = saldo;
    }

}
