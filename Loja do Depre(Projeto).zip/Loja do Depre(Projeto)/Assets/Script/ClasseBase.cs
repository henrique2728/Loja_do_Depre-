﻿using UnityEngine;

public abstract class ClasseBase
{
    public int valorItem;
    public int tipoItem;
    public static int qitenstotais;
    public static int valorTotal;
    public abstract void AddCarrinho();
   
}

public class Classe1 : ClasseBase
{
    public Classe1(int valorItem, int tipoItem ) 
    {
        this.valorItem = valorItem;
        this.tipoItem = tipoItem;
    }
  
    public override void AddCarrinho()
    {
        valorTotal += valorItem;
        qitenstotais++;
    }

}

public class Classe2 : ClasseBase
{
    public Classe2(int valorItem, int tipoItem)
    {
        this.valorItem = valorItem;
        this.tipoItem = tipoItem;
    }

    public override void AddCarrinho()
    {
        valorTotal += valorItem;
        qitenstotais++;
    }
}
public class Classe3 : ClasseBase
{
    public Classe3(int valorItem, int tipoItem)
    {
        this.valorItem = valorItem;
        this.tipoItem = tipoItem;
    }

    public override void AddCarrinho()
    {
        valorTotal += valorItem;
        qitenstotais++;
    }
}
