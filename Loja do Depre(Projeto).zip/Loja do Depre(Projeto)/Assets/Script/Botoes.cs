﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Botoes : MonoBehaviour
{

    public ClasseBase pocaodVida = new Classe1(100, 1);
    public ClasseBase pocaodDano = new Classe1(200, 2);

    public ClasseBase comidaVida = new Classe2(300, 1);
    public ClasseBase comidaDano = new Classe2(100, 2);

    public ClasseBase armadura = new Classe3(5000, 1);
    public ClasseBase espada = new Classe3(1000, 2);

    public GameObject painel1;
    public GameObject painel2;
    public GameObject painel3;
    public GameObject painel4;
    public GameObject painelRequest;
    public GameObject painelRequest2;
    public GameObject painelRequest3;
    public GameObject painelRequest4;


    public Button armaduraButton;
    public Button espadaButton;

    public bool itemUnico = false;
    public int  valorClass;
    public int  tipoItem;
    public int  opcao;
    public bool itemUnicoC;

    public void Cancelar() 
    {
        if (valorClass == 3)
        {
            if (itemUnicoC == true)
            {
                DesatBotEsAr(true);
                ClasseBase.valorTotal = 0;
                ClasseBase.qitenstotais = 0;
            }
            else 
            {
                DesatBotEsAr(false);
                ClasseBase.valorTotal = 0;
                ClasseBase.qitenstotais = 0;
                itemUnico = false;
            }
           
        }
        else 
        {
            DesatBotEsAr(false);
            ClasseBase.valorTotal = 0;
            ClasseBase.qitenstotais = 0;
        }
    }
    public void Comprar()
    {
        if (Player.saldo < ClasseBase.valorTotal)
        {
            //não tem item
            painelRequest4.SetActive(true);
        }
        else
        {
            if (valorClass == 3)
            {
                if (itemUnicoC == false)
                {
                    if (itemUnico == true)
                    {
                        AtivarRequest(true);
                    }
                    else
                    {
                        //não tem item
                        painelRequest3.SetActive(true);
                    }
                }
                else
                {
                    AtivarRequest2(true);
                }

            }
            else
            {
                AtivarRequest(false);
                Player.saldo -= ClasseBase.valorTotal;
                ClasseBase.valorTotal = 0;
                ClasseBase.qitenstotais = 0;
            }
        }
        
    }
    public void ReceberClass(int valorClass)
    {
        this.valorClass = valorClass;
        AtivarPainel();
    }
    public void AtivarPainel()
    {
        if (valorClass == 1)
        {
            painel1.SetActive(true);
            painel2.SetActive(false);
            painel3.SetActive(false);
            painel4.SetActive(false);
        }
        else if (valorClass == 2)
        {
            painel2.SetActive(true);
            painel1.SetActive(false);
            painel3.SetActive(false);
            painel4.SetActive(false);
        }
        else if(valorClass == 3)
        {

            painel3.SetActive(true);
            painel2.SetActive(false);
            painel1.SetActive(false);
            painel4.SetActive(false);

        }
        else 
        {
            painel3.SetActive(false);
            painel2.SetActive(false);
            painel1.SetActive(false);
            painel4.SetActive(true);
        }

    }
    public void AddCarrinho(int op)
    {
        if (valorClass == 1)
        {
            if (op == 1)
            {
                pocaodVida.AddCarrinho();
            }
            else
            {
                pocaodDano.AddCarrinho();
            }
        }
        else if (valorClass == 2)
        {
            if (op == 1)
            {
                comidaVida.AddCarrinho();
            }
            else
            {
                comidaDano.AddCarrinho();
            }
        }
        else
        {
            if (op == 1)
            {
                opcao = op;
                armadura.AddCarrinho();
                DesatBotEsAr(true);
                itemUnico = true;
            }
            else
            {
                opcao = op;
                espada.AddCarrinho();
                DesatBotEsAr(true);
                itemUnico = true;
            }
        }
    }
    public void DesatBotEsAr(bool a) 
    {
        if (a == true)
        {
            armaduraButton.image.color = Color.red;
            espadaButton.image.color = Color.red;
            armaduraButton.enabled = false;
            espadaButton.enabled = false;
        }
        else 
        {
            armaduraButton.image.color = Color.white;
            espadaButton.image.color = Color.white;
            armaduraButton.enabled = true;
            espadaButton.enabled = true;
        }
       
    }
   
    public void ConfirmarCompra() 
    {
        AtivarRequest(false);
        itemUnicoC = true;
        Player.saldo -= ClasseBase.valorTotal;
        ClasseBase.valorTotal = 0;
        ClasseBase.qitenstotais = 0;

    }
    public void CancelarCompra()
    {
        AtivarRequest(false);
        DesatBotEsAr(false);
        itemUnicoC = false;
        itemUnico = false;
        ClasseBase.valorTotal = 0;
        ClasseBase.qitenstotais = 0;
    }
   
    
    public void ConfirmarReq2()
    {
        AtivarRequest2(false);
    }
    public void ConfirmarReq3()
    {
        AtivarRequest3(false);
    }
    public void ConfirmarReq4()
    {
        AtivarRequest4(false);
    }
    
    
    public void AtivarRequest(bool a) 
    {
        painelRequest.SetActive(a);
    }
    public void AtivarRequest2(bool a)
    {
        painelRequest2.SetActive(a);
    }
    public void AtivarRequest3(bool a)
    {
        painelRequest3.SetActive(a);
    }
    public void AtivarRequest4(bool a)
    {
        painelRequest4.SetActive(a);
    }
}
