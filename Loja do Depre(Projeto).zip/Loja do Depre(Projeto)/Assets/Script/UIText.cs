﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIText : MonoBehaviour
{
    public Text valorTotal;
    public Text qItens;
    public Text saldo;


    void Update()
    {
        valorTotal.text = ClasseBase.valorTotal.ToString();
        qItens.text = ClasseBase.qitenstotais.ToString();
        saldo.text = Player.saldo.ToString();

    }
}
